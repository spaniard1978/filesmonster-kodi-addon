#!/usr/bin/env python
# -*- coding: utf-8 -*-
#------------------------------------------------------------
# filesmonster - KODI Plugin
# Addon for filesmonster.com
# http://github.com/spaniard1978/adult-pay-sites
#------------------------------------------------------------

    
   
	

import xbmcaddon

   
xbmcaddon.Addon('plugin.video.filesmonster').setSetting('loguea_out', 'si')


