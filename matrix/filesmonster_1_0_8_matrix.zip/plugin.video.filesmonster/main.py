#!/usr/bin/env python
# -*- coding: utf-8 -*-
#------------------------------------------------------------
# filesmonster - KODI Plugin
# Addon for filesmonster.com
# http://github.com/spaniard1978/adult-pay-sites
#------------------------------------------------------------



    
import sys
import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import urllib.parse
import xbmcgui
import xbmcplugin
import re
import os
import xbmc
import xbmcaddon
import time
import datetime
import threading
import json
import http.cookiejar
import threading





		

#addon values for dialogs
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addonid   = addon.getAddonInfo('id')
actual_version=addon.getAddonInfo('version')	

	
token='Nzc3NITnVKUABMKq9YxO9pHj6B0'




# for krypton if ssl error is not solved
xbmc_version = xbmc.getInfoLabel( "System.BuildVersion" )
version=xbmc_version.split(".")
version=int(version[0])
if (version>=17):
	import ssl
	ssl._create_default_https_context = ssl._create_unverified_context


		
	
		
		
#Absolute path to icons
addonPath = xbmcaddon.Addon().getAddonInfo("path")
latest_icon = os.path.join(addonPath, 'resources', 'images', 'latest_folder_menu_main.png')
next_icon = os.path.join(addonPath, 'resources', 'images', 'next_menu_icon.png')
search_icon = os.path.join(addonPath, 'resources', 'images', 'search_folder_menu_main.png')
favorites_icon = os.path.join(addonPath, 'resources', 'images', 'favorites_folder_menu_main.png')
settings_icon = os.path.join(addonPath, 'resources', 'images', 'settings_folder_menu_main.png')
categories_icon = os.path.join(addonPath, 'resources', 'images', 'categories_folder_menu_main.png')
downloads_icon = os.path.join(addonPath, 'resources', 'images', 'my_downloads_folder_menu_main.png')
fanart_main = os.path.join(addonPath,  'resources', 'images','fanart_main_logo_2.jpg')




#get language and change menus
my_addon = xbmcaddon.Addon()
language = my_addon.getSetting('language')





if language=="Español (España)":
	text_latest_videos='Últimos vídeos'
	text_categories='Categorías'
	text_search_content="Buscar"
	text_my_favorites='Mis favoritos'
	text_my_downloads="Mis descargas"
	text_settings="Preferencias"
	text_login="acceso (login)"
	text_add_to_my_favorites="Añadir a favoritos en filesmoster"
	text_remove_from_my_favorites="Quitar de mis favoritos en filesmonster"
	text_download_video="Descargar el vídeo"
	text_user="usuario"
	text_login_with_your="Accede con tu"
	text_filesmonster_acount="cuenta de filesmonster.com"
	text_not_logged="No se podido acceder con tu usuario y contraseña "
	text_reason="Causa: "
	text_file_downloaded_yesno="¿Quieres descargar este vídeo?"
	text_file_delete_yesno="¿Estás seguro de que quieres borrar este vídeo?"
	text_file_downloaded="El vídeo se está descargando en la ruta de descarga (puedes cambiarla en preferencias). Puedes controlar el proceso de descarga desde 'Mis descargas' en el menú principal"
	text_video_info="Información del vídeo"
	text_added_favorites="El vídeo se añadido a tus favoritos de filesmonster.com. Puedes verlo desde el menú principal"
	text_yet_favorites="El vídeo ya estaba en tus favoritos"
	text_name_download="Se descargará con este nombre"
	text_cancel_download="¿Cancelar la descarga?"
	text_remove_record_download="Borrar este registro"
	text_remove_download="Borrar este vídeo"
	text_file_canceled="Para cancelar las descargas tienes que salir de Kodi y volver a entrar, entonces podrás borrar el archivo"
	text_file_deleted="Vídeo borrado de la carpeta de descargas"
	text_refresh_download="Actualizar datos de descargas"
	text_no_premium="Necesitas acceder con una cuenta premium activa de filesmonster.com para poder ver este vídeo, introduce tus datos en preferencias"
	text_file_exist="Un archivo con este nombre ya existe o se está descargando en tu carpeta de descargas"
	text_next="Siguientes"
	text_search_not_avaliable="La búsqueda estará disponible en breve"
	text_page="Página"
	at_least_4="El término a buscar tiene que tener al menos 4 caracteres"
	text_updates="Buscar actualizaciones del add-on"
	
else:
	text_latest_videos='Latest videos'
	text_categories='Categories'
	text_search_content="Search"
	text_my_favorites='My favorites'
	text_my_downloads="My Downloads"
	text_settings="Settings"
	text_login="login"
	text_add_to_my_favorites="Add to my filesmoster favorites"
	text_remove_from_my_favorites="Remove from my filesmonster favorites"
	text_download_video="Download video"
	text_user="user"
	text_login_with_your="Login with your"
	text_filesmonster_acount="filesmonster.com acount"
	text_not_logged="Not Logged with your useranme and password "
	text_reason="Reason: "
	text_file_downloaded_yesno="Do you want to download this video?"
	text_file_delete_yesno="Do you really want to delete this video?"
	text_file_downloaded="Video is being downloading in the download path (you can change it in your settings). You can control the download process from 'My downloads' in the main menu"
	text_video_info="Video info"
	text_added_favorites="Video added to your favorites in filesmonter.com. Watch it from the main menu"
	text_yet_favorites="This video is in your favorites list yet "
	text_name_download="Filename for downloaded video"
	text_cancel_download="Cancel download?"
	text_remove_record_download="Remove this record"
	text_remove_download="Delete this video"
	text_file_canceled="To cancel downloads you must exit Kodi and enter again. Then you can delete it without problems"
	text_file_deleted="Video deleted from download folder"
	text_refresh_download="Refresh download data"
	text_no_premium="You need to use an active premium account of filesmonster.com to watch this video, add it in settings"
	text_file_exist="A file with the same filename already exists in your download folder or it's downloading"
	text_next="Next"
	text_search_not_avaliable="Search will be avaliable soon"
	text_page="Page"
	at_least_4="Search item must have at least 4 characters"
	text_updates="Check for add-on updates"


#Get active value
my_addon = xbmcaddon.Addon()
username = my_addon.getSetting('username')
password = my_addon.getSetting('password')
if (username==''):my_addon.setSetting('active', "not active")
active = my_addon.getSetting('active')
logout = my_addon.getSetting('logout')


my_addon.setSetting('installed_version', actual_version)
	
if (logout=='Yes'): 
	my_addon.setSetting('active', "not active")
	my_addon.setSetting('username', "")
	my_addon.setSetting('password', "")
	my_addon.setSetting('logout', "No")
	active="no"
if (active=='active'):
	status_login=text_settings+" | [COLOR brown]"+text_user+": "+username+"[/COLOR]"
if (active!='active'): 
	video_value0=(text_video_info, ' XBMC.Action(Info)' )
	video_value=(text_login_with_your,  ' XBMC.Action(Info)')
	video_value2=(text_filesmonster_acount, ' XBMC.Action(Info)')
	status_login=text_settings+" | [COLOR brown] "+text_login+"[/COLOR]"
	my_addon.setSetting('premium', "Not logged")

	

#set default downloadpath int settings.xml file
download_path = my_addon.getSetting('download_path')
__addon__       = xbmcaddon.Addon(id='plugin.video.filesmonster')
__addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 
if (download_path==''): my_addon.setSetting('download_path', __addondir__ +"download/")




def checkversion():
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")	
	request = urllib.request.Request("https://github.com/spaniard1978/filesmonster-kodi-addon/blob/master/version_checker_matrix")
	result = urllib.request.urlopen(request)
	data2=result.read().decode('utf-8')
	patronvideos ="last_version#-(.*?)-#last_version"
	matches = re.compile(patronvideos,re.DOTALL).findall(data2)
	for  version  in matches:
		my_addon.setSetting('last_version', version)
		

	xbmc.executebuiltin("Dialog.Close(busydialognocancel)")	
	
	if version!=actual_version:
		xbmcgui.Dialog().ok(addonname, "There's a new version avaliable: "+version+" (installed: "+actual_version+"). You can download it fom https://github.com/spaniard1978/filesmonster-kodi-addon")
	else: xbmcgui.Dialog().ok(addonname, "You're using the last avaliable version ("+version+") found in https://github.com/spaniard1978/filesmonster-kodi-addon")

	return





def open_settings():
	#xbmc.executebuiltin('Addon.OpenSettings(plugin.video.filesmonster)')
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")	
	makelogin("from_menu")
	xbmcaddon.Addon().openSettings()
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")	
	makelogin("check")
	
	return
	
	






def makelogin(from_where):	
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	#test if login is correct (if it's not remove the value in settings)ç
	login_url="http://filesmonster.com/api/public/login"
	d = dict(username=username, password=password)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8') 
	request = urllib.request.Request(login_url, data)

	
	try:
		response=urllib.request.urlopen(request, timeout = 100)
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
	except urllib.error.URLError as e:
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, "timeout error: try agin")
		
	
	
	cookies = '; '.join(x.split(';', 1)[0] for x in response.headers.get("Set-Cookie"))
	cookies=cookies.replace("yab_logined=0;", "")
	cookies=cookies.replace("yab_uid=0;", "")
	data=response.read()
	data=json.loads(data)
	status=data['status']
	if status!='success': 
		reason=data['fail_reason']
		alerta=""
		if "try again" in reason: alerta="Login in filesmonster.com using your browser from this IP and check that your are not a robot, and then try to login here again "
		if (from_where!='from_menu'): xbmcgui.Dialog().ok(addonname,text_reason+reason+" "+alerta)
		addon.setSetting('active', reason)
		addon.setSetting('premium', '')
		addon.setSetting('traffic', 'O Mb')
		
		if (from_where!='from_menu'):xbmc.executebuiltin('Container.Refresh')
	if status=='success': 
		
		#get account info
		status_url="http://filesmonster.com/api/public/accountStatus"
		cookieProcessor = urllib.request.HTTPCookieProcessor()
		opener = urllib.request.build_opener(cookieProcessor) 
		response = opener.open(request,timeout=100)
		data = opener.open(status_url)
		data=data.read()
		data=json.loads(data)
		premium=data["expire"]
		until=time.strftime("%B %d, %Y - %H:%M h", time.localtime(premium))
		traffic=int(data['available_traffic'])/1073741824
		traffic=str(traffic)
		addon.setSetting('active', "active")
		addon.setSetting('premium', until)
		addon.setSetting('traffic', traffic+" Gb")
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmc.executebuiltin('Container.Refresh')
	
	return


def get_url(url_base):
	xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
	url_info_video="http://content-cooperation.com/api/webmaster/getInfo"
	d = dict(token=token,  url='https://filesmonster.com/download.php?id='+url_base)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8')
	request2 = urllib.request.Request(url_info_video, data)
	
	response2=urllib.request.urlopen(request2, timeout = 10)
	data2=response2.read()
	data2=json.loads(data2)
	thumbnail=data2['poster']
	title=data2['name']
	plot=data2['description']
	category=data2['category']
	what_type=data2['type']
		
		
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	#test if login is correct (if it's not remove the value in settings)ç
	login_url="http://filesmonster.com/api/public/login"
	d = dict(username=username, password=password)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8')
	request = urllib.request.Request(login_url, data)

	
	try:
		response=urllib.request.urlopen(request, timeout = 10)
	except urllib.error.URLError as e:
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, "timeout error: try agin")
		
	#cookies=response.info()['Set-Cookie']
	cookies = '; '.join(x.split(';', 1)[0] for x in response.headers.get("Set-Cookie"))
	cookies=cookies.replace("yab_logined=0;", "")
	cookies=cookies.replace("yab_uid=0;", "")
	data=response.read()
	data=json.loads(data)
	status=data['status']
	if status=='success': 
		#get account info
		download_url="http://filesmonster.com/api/public/premiumDownload"
		cookieProcessor = urllib.request.HTTPCookieProcessor()
		opener = urllib.request.build_opener(cookieProcessor) 
		response = opener.open(request,timeout=100)
		
		d = dict(id=url_base)
		f = urllib.parse.urlencode(d)
		post = f.encode('utf-8')
		
		data = opener.open(download_url, post)
		data=data.read()
		data=json.loads(data)
		url=''
		status=data['status']
		if status=='success': 
			url=data['url']
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		if status!='success':
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
			fail_reason=data['fail_reason']
			xbmcgui.Dialog().ok(addonname, fail_reason+" "+url_base)
			
	return {'url':url, 'title':title ,'thumbnail':thumbnail  ,'plot':plot, 'category':category, 'what_type': what_type}


	
#dowload progress
def progress(count, blockSize, totalSize):
	percent = int(count*blockSize*100/totalSize)
	if percent<0:percent=''
	downloaded=str(((count*blockSize)*0.0009765625)*0.001)
	total_size=round((totalSize*0.0009765625)*0.001,3)
	totalmb=str(total_size)

	directory=download_path
	file_txt=directory+"/"+new_filename+".txt"
	f=open(file_txt, "a+")
	if percent<101:f.write(str(percent)+"% | "+str(downloaded)+"Mb/"+str(totalmb)+"Mb | \n")
	if percent>=101:f.write("Error \n")
	f.close()
	return






base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')




def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)
    
    
   
	

    

setting_value=(text_settings, 'Addon.OpenSettings(plugin.video.filesmonster)')

mode = args.get('mode', None)


 
def refresh():
	if mode[0]=='my_downloads':xbmc.executebuiltin('Container.Refresh')

def carga():
	directory=download_path
	if not os.path.exists(directory):os.makedirs(directory)
	records=os.listdir(directory)
	for record in records:
		extension=".txt"
		if extension in record:
			f=open(directory+record, 'r')
			data = f.readlines()
			f.close()
			last='downloading...'
			last=data[len(data)-1]
			file_name=record.replace(".txt" , "")
			url2 = build_url({'mode':'cancel_download', 'foldername': file_name})
			cancel_download=(text_cancel_download, 'RunPlugin('+url2+')')
			url2 = build_url({'mode':'remove_download', 'foldername': file_name})
			remove_download=(text_remove_download, 'RunPlugin('+url2+')')  
			url2 = build_url({'mode':'refresh_download', 'foldername': file_name})
			refresh_download=(text_refresh_download, 'RunPlugin('+url2+')') 
			info_show=(text_video_info, ' XBMC.Action(Info)' )
			url = download_path+file_name
			li = xbmcgui.ListItem("[COLOR brown]"+file_name+"[/COLOR]  "+last)
			li.setArt({'icon':downloads_icon})
			li.setArt({'fanart':fanart_main})
			info = {'title': file_name, 'plot':last}
			li.setInfo('video', info)
			li.setProperty('IsPlayable', 'true')
			li.addContextMenuItems([cancel_download, remove_download,refresh_download, info_show] ,replaceItems=True)
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
	threading.Timer(3, refresh).start()


def get_info(description, url_base):
		#if it's active user or not choosse what to show
    	genre_s="Porn"
    	year='n/a'
    	duration='0:0:0'
    	video_format="480x368, DivX 5, 814kbps"
    	audio_format=""
    	studio=""
    	castfull=''
    	director=''
    	fanart=''
    	plot=''
    	language='English'
    	duration_s=0
    	is_folder=='no'
    	#description='';
    	if is_folder=='no':

    		base=url_base.split("=")
    		id_base=base[1]
    		patronvideos ='Release Year:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for year in matches:
    			year=year
    		patronvideos ='Duration:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for duration in matches:
    			duration=duration.strip()
    			duration=duration.replace("min", "")
    			duration=duration.replace("h", ":")
    			duration=duration.replace("mn", ":")
    			duration=duration.replace("s", ":")
    			
    		patronvideos ='Video:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for video in matches:
    			video_format=video
    		patronvideos ='Audio:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for audio in matches:
    			audio_format=audio
    		patronvideos ='Studio:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for studio in matches:
    			studio=studio
    		patronvideos ='Cast:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for cast in matches:
    			castfull=cast
    		patronvideos ='Language:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for language in matches:
    			language=language
    		patronvideos ='src=(.*?)border'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for fanart in matches:
    			fanart=fanart.replace('"', '')
    		patronvideos ='Genres:(.*?)<br'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for genre_s in matches:
    			genre_s=genre_s
    		patronvideos ='(.*?)Format'
    		matches = re.compile(patronvideos,re.DOTALL).findall(description)
    		for plot in matches:
    			plot=plot.replace(castfull, '')
    			plot=plot.replace("Cast:", '')
    			plot=plot.replace(year, '')
    			plot=plot.replace("Release Year:", '')
    			plot=plot.replace(studio, '')
    			plot=plot.replace("Studio:", '')
    			plot=plot.replace(genre_s, '')
    			plot=plot.replace("Genres:", '')
    			plot=plot.replace("<br />", "")				
    			plot=plot.replace("\\u0027", "'")
    			plot=plot.replace("&quot;", '"')
    		
			
    		
    	video=url
    
    	if fanart=='':fanart=fanart_main
    	poster=thumbnail
    	banner=fanart
    	genre=genre_s
    	language=language.lower()
    	language_s=''
    	if language=='english':language_s="en"
    	if language=='spanish':language_s="es"
    	if language=='german':language_s="de"
    	if language=='french':language_s="fr"
    	if language=='russian':language_s="ru"
    	if language=='italian':language_s="it"
    	video_format=video_format.lower()
    	video_format=video_format.split(',')
    	
    	if not"," in video_format: video_format=""
    	howmany=len(video_format)
    	
    	width=1
    	height=1
    	codec_format_1='xvid'
    	if howmany>=2:
    		dimension=video_format[0]
    		if "(" in dimension:
    			dimension=dimension.split('(')
    			dimension=dimension[0]
    		if "x" in dimension:
    			dimension_part=dimension.split('x')
    			width=dimension_part[0]
    			height=dimension_part[1]
    		codec_format=video_format[1].lstrip()
    		if (codec_format=='windows media video'): codec_format='wmv3'
    		codec_format=codec_format.split(' ')
    		codec_format_1=codec_format[0]
    		if (codec_format_1=='avc' or codec_format_1=='h265' ): codec_format_1='hevc'
    		studio=studio.replace("<b>", "")
    		studio=studio.replace("</b>", "")
    		plot=plot.replace("<b>", "")
    		plot=plot.replace("</b>", "\n")
    		year=year.replace("<b>", "")
    		year=year.replace("</b>", "")
    		genre=genre.replace("<b>", "")
    		genre=genre.replace("</b>", "")
    		height=height.replace("<b>", "")
    		height=height.replace("</b>", "")
    		width=width.replace("<b>", "")
    		width=width.replace("</b>", "")
    		width=width.strip()   		
    		height=height.strip()
    
    
    	audio_chanells=2
    	castfull=castfull.replace("<b>", "")
    	castfull=castfull.replace("</b>", "")
    	cast=castfull.split(',')


    	try:
    		aspect=float(width)/float(height)
    		aspect=round(aspect, 2)
    	except ValueError:
    		aspect='' 
    		

    	
    	
    	duration=duration.replace("<b>", "")
    	duration=duration.replace("</b>", "")
    	duration=duration.replace("hours", ":")
    	duration=duration.replace("min.", "")
    	duration=duration.replace("minutes", "")
    	duration=duration.replace(" ", "")
    	duration2=duration.split(':')
    	how_many=duration.count(':') + 1
    	hours=0
    	minutes=0
    	seconds=0
    	if how_many==3 and duration2[0].isdigit() and duration2[1].isdigit() and duration2[2].isdigit():
    		hours=int(duration2[0])
    		minutes=int(duration2[1])
    		if (duration2[2]!=''): seconds=int(duration2[2])
    	if how_many==2: 
    		minutes=int(duration2[0])
    		if (duration2[1]!=''):seconds=int(duration2[1])
    	if how_many==1: 
    		if (duration2[0]!=''):seconds=int(duration2[0])	
    	duration_s=seconds+(minutes*60)+(hours*60*60)
    	
    	plot=plot.replace("<b>", "")
    	plot=plot.replace("</b>", "")
    	studio=studio.replace("<b>", "")
    	studio=studio.replace("</b>", "")
    	
    	return {'duration_s':duration_s,'language_s':language_s, 'audio_chanells':audio_chanells, 'codec_format_1':codec_format_1, 'width':width, 'height':height, 'aspect':aspect, 'title':title  ,'fanart':fanart ,'plot':plot, 'genre_s':genre_s, 'video':url, 'year':year,   'studio':studio, 'director':director,  'cast':cast}









   
#makes them items form menu not videos (needed for some skins) for main menu and categories
if mode is None: xbmcplugin.setContent(addon_handle, '')
elif mode[0] == 'categories' or mode[0] == 'my_favorites'  or mode[0] == 'my_downloads' : 
	xbmcplugin.setContent(addon_handle, '')


    
if mode is None:

    if active=='active':
    	url = build_url({'mode': 'folder', 'foldername': 'latest' , 'start': '0'})
    	li = xbmcgui.ListItem(text_latest_videos)
    	li.setArt({'icon':latest_icon})
    	li.setArt({'fanart':fanart_main})
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    	li.addContextMenuItems([settings] ,replaceItems=True)
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)


    	url = build_url({'mode': 'categories', 'foldername': 'categories'})
    	li = xbmcgui.ListItem(text_categories)
    	li.setArt({'icon':categories_icon})
    	li.setArt({'fanart':fanart_main,})
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    	li.addContextMenuItems([settings] ,replaceItems=True)
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    	url = build_url({'mode': 'search', 'foldername': 'search', 'start': '0', 'word-q': '0'})
    	li = xbmcgui.ListItem(text_search_content)
    	li.setArt({'icon':search_icon})
    	li.setArt({'fanart':fanart_main,})
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    	li.addContextMenuItems([settings] ,replaceItems=True)
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    	
    	url = build_url({'mode': 'my_favorites', 'foldername': 'favorites'})
    	li = xbmcgui.ListItem(text_my_favorites)
    	li.setArt({'icon':favorites_icon})
    	li.setArt({'fanart':fanart_main,})
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    	li.addContextMenuItems([settings] ,replaceItems=True)
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    	url = build_url({'mode': 'my_downloads', 'foldername': 'my_downloads'})
    	li = xbmcgui.ListItem(text_my_downloads)
    	li.setArt({'icon':downloads_icon})
    	li.setArt({'fanart':fanart_main,})
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    	li.addContextMenuItems([settings] ,replaceItems=True)
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode':'settings', 'foldername': 'settings'})
    li = xbmcgui.ListItem(status_login)
    li.setArt({'icon':settings_icon})
    li.setArt({'fanart':fanart_main,})
    url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    settings=(status_login, 'RunPlugin('+url2+')')  
    li.addContextMenuItems([settings] ,replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,  listitem=li, isFolder=False)

    url = build_url({'mode':'updates', 'foldername': 'updates'})
    li = xbmcgui.ListItem(text_updates)
    li.setArt({'icon':settings_icon})
    li.setArt({'fanart':fanart_main,})
    url2 = build_url({'mode':'updates', 'foldername': 'updates'})
    settings=(status_login, 'RunPlugin('+url2+')')  
    li.addContextMenuItems([settings] ,replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,  listitem=li, isFolder=False)
 


elif mode[0] == 'categories': 
	categories=[]
	categories=["3D Porno", "3D stereo",  "Amateurish", "Anal", "Anime and Hentai", "BBW",  "bdsm", "Big boobs", "Bisexual", "Black", "Blondes", "Bukkake", "Cartoons", "Celebrities",  "Censored asian", "Clasic Sex", "Documentaries","Erotic & Softcore",  "Extremals", "Female Muscle", "Femdom and Strapon", "Fisting and Dildo", "for mobile phones", "Full-length films", "Gay 3D stereo", "Gay Asian", "Gay BDSM","Gay Full-length films" , "Gay Solo", "Gay Unusual", "Gay Retro", "Gays", "Gonzo (point of view)", "Hairy" , "HD Clips" , "Hidden camera" , "Interrarcial" , "Latino" , "Lesbians", "Massage" , "Masturbation" , "Mature, MILF" , "Old and Young", "Oral"  , "Orgies"  , "Peeing"   , "Pregnant"  , "Public sex"  , "Retro"  , "Russian"  , "Sex Machines"  , "Teens" , "Threesome"  , "Transexual"  , "Uncesored asian"  , "Unusual"  ]
	for category in categories:
		url = build_url({'mode': 'folder', 'foldername': category, 'start': '0'})
		li = xbmcgui.ListItem(category)
		li.setArt({'icon':categories_icon})
		li.setArt({'fanart':fanart_main})
		url2 = build_url({'mode':'settings', 'foldername': 'settings'})
		settings=(status_login, 'RunPlugin('+url2+')')  
		li.addContextMenuItems([settings] ,replaceItems=True)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)	

    

                          
    	
	                           
elif mode[0] == 'settings': 
	open_settings()	

elif mode[0] == 'updates': 
	checkversion()	
       
        
        
elif mode[0] == 'search':
    foldername = args['foldername'][0]   
    start=args['start'][0]
    word=args['word-q'][0]
    #xbmcgui.Dialog().ok(addonname, word)
    istart=0   
    foldername="latest"
    remember_search = addon.getSetting('remember_search')
    last_search=""
    if remember_search=="Yes": last_search= addon.getSetting('last_search')
    if remember_search=="": last_search= addon.getSetting('last_search')
    if word=='0': 
    	keyboard = xbmc.Keyboard(last_search, text_search_content, False)
    	keyboard.doModal()
    	if len(keyboard.getText())<=3: xbmcgui.Dialog().ok(addonname, at_least_4)
    	if keyboard.isConfirmed() and keyboard.getText() != "":
    		word=keyboard.getText()
    		my_addon.setSetting('last_search', word)
    	else: sys.exit("close - cancel")
    if len(word)<=3: word='zzzzzzzz'		
    url_info_video="http://content-cooperation.com/api/webmaster/searchCatalog"
    

    d = dict(token=token, q=word,  limit="50", offset=start)
    f = urllib.parse.urlencode(d)
    data = f.encode('utf-8')

    request2 = urllib.request.Request(url_info_video, data)
   
    response2=urllib.request.urlopen(request2, timeout = 10)
    data2=response2.read()
    data2=json.loads(data2)
    data2 = list({ each['name'] : each for each in data2 }.values())
    cuantos=len(data2)
    count=0
    title=''
    
    while count<cuantos:
    	title=data2[count]['name']
    	
    	 
    	#if it's active user or not choosse what to show
    	id_base=''
    	active = my_addon.getSetting('active')
    	url=''
    	thumbnail=''
    	category=''
    	fanart=''
    	duration=''

    	
    	if active=='active':
    		url_base=data2[count]['url']
    		url_main=data2[count]['url']
    		thumbnail=data2[count]['poster']
    		category=data2[count]['category']
    		description=data2[count]['description']
    		base=url_base.split("=")
    		is_folder="no"
    		if "fid" in url_base: is_folder="yes"
    		id_base=base[1]
    		id_base=url_base.split("=")
    		id_base=id_base[1]
    		is_folder="no"
    		if "fid" in url_base: is_folder="yes"
    	if active!='active': url = build_url({'mode': 'no_premium', 'foldername': 'no_premium'})
    	data=get_info(description, url_main)
    	duration_s=data['duration_s']
    	language_s=data['language_s']
    	audio_chanells=data['audio_chanells']
    	codec_format_1=data['codec_format_1']	
    	width=data['width']	
    	height=data['height']	
    	aspect=data['aspect']	
    	plot=data['plot']	
    	title=data['title']	
    	fanart=data['fanart']	
    	genre=data['genre_s']
    	video=data['video']		
    	year=data['year']	
    	studio=data['studio']	
    	director=data['director']	
    	cast=data['cast']	
    	fanart=fanart.replace("imager/w_400/h_400", "pic_b")
    	fanart=fanart.replace("imager/w_200/h_200", "pic_b")
    	fanart=fanart.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_400", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_200/h_200", "pic_b")	
    	thumbnail=thumbnail.strip()
    	plot=plot.strip()
    	genre=genre+" ("+category+")"



  	
    	what_icon=''
    	if is_folder=="yes": what_icon="[COLOR red][+][/COLOR] "
    	poster=thumbnail
    	banner=fanart
    	li = xbmcgui.ListItem(what_icon+title)
    	info = {'genre': genre,'year': year,'title': title, 'originaltitle':title, 'studio':studio, 'director':director,  'cast':cast, 'plot':plot, 'mpaa': 'NC-17',  'duration':duration_s }
    	li.setInfo('video', info)
    	li.setArt({'fanart':fanart, 'thumb':thumbnail , 'poster':poster , 'banner':banner})
    	li.addStreamInfo('audio', { 'language': language_s,  'channels': audio_chanells})
    	li.addStreamInfo('video', {'codec': codec_format_1, 'width': width ,'height': height , 'aspect':aspect, })
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    
    	if (active=='active'):
    		video_value0=(text_video_info, 'XBMC.Action(Info)' )
    		url2 = build_url({'mode':'favorites', 'foldername': url_base})
    		video_value=(text_add_to_my_favorites, 'RunPlugin('+url2+')' )
    		url2 = build_url({'mode':'download', 'foldername': id_base})
    		video_value2=(text_download_video, 'RunPlugin('+url2+')')
    
    
    	if is_folder=="no": li.addContextMenuItems([video_value0, video_value, video_value2, settings ] ,replaceItems=True)
    	if is_folder=="yes": li.addContextMenuItems([video_value0, video_value,  settings ] ,replaceItems=True)
    	if is_folder=="yes": url = build_url({'mode': 'afolder', 'foldername': id_base})
    	if is_folder=="no" and active=="active": url = build_url({'mode': 'play_video', 'foldername': id_base})
    	if is_folder=="no" and active!="active": url = build_url({'mode': 'no_premium', 'foldername': id_base})

    
    	if is_folder=="no": xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False) 
    	if is_folder=="yes": xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True) 
    	
    
    
    
    	count=count+1  
		#values of video from json
    	
    #next page start +50	
    start=int(start)
    start=start+50
    url = build_url({'mode': 'search', 'foldername': category , 'start': start, 'word-q': word ,})
    li = xbmcgui.ListItem(text_next)
    li.setArt({'icon':next_icon})
    li.setArt({'fanart':fanart_main})
    url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    settings=(status_login, 'RunPlugin('+url2+')')
    li.addContextMenuItems([settings] ,replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
        
        
        

elif mode[0] == 'folder':
    foldername = args['foldername'][0]   
    start=args['start'][0]
    istart=0    
    url_info_video="http://content-cooperation.com/api/webmaster/listCatalog"
    
    if foldername=='latest' :
    	d = dict(token=token, what="files", limit="50", offset=start)
    	f = urllib.parse.urlencode(d)
    	data = f.encode('utf-8')
    	
    if foldername!='latest' :
    	d = dict(token=token, what="files", category=foldername, limit="50", offset=start)
    	f = urllib.parse.urlencode(d)
    	data = f.encode('utf-8')

    request2 = urllib.request.Request(url_info_video, data)


    response2=urllib.request.urlopen(request2, timeout = 10)
    data2=response2.read()
    data2=json.loads(data2)
    cuantos=len(data2)
    count=0
    title=''
    
    while count<cuantos:
    	title=data2[count]['name']
    	
    	 
    	#if it's active user or not choosse what to show
    	id_base=''
    	active = my_addon.getSetting('active')
    	url=''
    	thumbnail=''
    	category=''
    	fanart=''

    	
    	if active=='active':
    		url_base=data2[count]['url']
    		url_main=data2[count]['url']
    		thumbnail=data2[count]['poster']
    		category=data2[count]['category']
    		description=data2[count]['description']
    		base=url_base.split("=")
    		is_folder="no"
    		if "fid" in url_base: is_folder="yes"
    		id_base=base[1]
    		id_base=url_base.split("=")
    		id_base=id_base[1]
    		is_folder="no"
    		if "fid" in url_base: is_folder="yes"
    	if active!='active': url = build_url({'mode': 'no_premium', 'foldername': 'no_premium'})
    	
    	data=get_info(description, url_main)
    	duration_s=data['duration_s']
    	language_s=data['language_s']
    	audio_chanells=data['audio_chanells']
    	codec_format_1=data['codec_format_1']	
    	width=data['width']	
    	height=data['height']	
    	aspect=data['aspect']	
    	plot=data['plot']	
    	title=data['title']	
    	fanart=data['fanart']	
    	genre=data['genre_s']
    	video=data['video']		
    	year=data['year']	
    	studio=data['studio']	
    	director=data['director']	
    	cast=data['cast']	
    	fanart=fanart.replace("imager/w_400/h_400", "pic_b")
    	fanart=fanart.replace("imager/w_200/h_200", "pic_b")
    	fanart=fanart.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_400", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
    	thumbnail=thumbnail.replace("imager/w_200/h_200", "pic_b")	
    	thumbnail=thumbnail.strip()
    	plot=plot.strip()
    	genre=genre+" ("+category+")"



  	
    	poster=thumbnail
    	banner=fanart
    	li = xbmcgui.ListItem(title)
    	info = {'genre': genre,'year': year,'title': title, 'originaltitle':title, 'studio':studio, 'director':director,  'cast':cast, 'plot':plot, 'mpaa': 'NC-17',  'duration':duration_s }
    	li.setInfo('video', info)
    	li.setArt({'fanart':fanart, 'thumb':thumbnail , 'poster':poster , 'banner':banner})
    	li.addStreamInfo('audio', { 'language': language_s,  'channels': audio_chanells})
    	li.addStreamInfo('video', {'codec': codec_format_1, 'width': width ,'height': height , 'aspect':aspect, })
    	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    	settings=(status_login, 'RunPlugin('+url2+')')  
    
    	if (active=='active'):
    		video_value0=(text_video_info, ' Action(Info)' )
    		url2 = build_url({'mode':'favorites', 'foldername': url_base})
    		video_value=(text_add_to_my_favorites, 'RunPlugin('+url2+')' )
    		url2 = build_url({'mode':'download', 'foldername': id_base})
    		video_value2=(text_download_video, 'RunPlugin('+url2+')')
    
    
    	if is_folder=="no": li.addContextMenuItems([video_value0, video_value, video_value2, settings ] ,replaceItems=True)
    	if is_folder=="yes": li.addContextMenuItems([video_value0, video_value,  settings ] ,replaceItems=True)
    	if is_folder=="yes": url = build_url({'mode': 'afolder', 'foldername': id_base})
    	if is_folder=="no" and active=="active": url = build_url({'mode': 'play_video', 'foldername': id_base})
    	if is_folder=="no" and active!="active": url = build_url({'mode': 'no_premium', 'foldername': id_base})

    
    	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False) 
    	
    
    
    
    	count=count+1  
		#values of video from json
    	
    #next page start +50	
    start=int(start)
    start=start+50
    url = build_url({'mode': 'folder', 'foldername': category , 'start': start})
    li = xbmcgui.ListItem(text_next)
    li.setArt({'icon':next_icon})
    li.setArt({'fanart':fanart_main})
    url2 = build_url({'mode':'settings', 'foldername': 'settings'})
    settings=(status_login, 'RunPlugin('+url2+')')  
    li.addContextMenuItems([settings] ,replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

   

    
    







	

elif mode[0]=='my_downloads':
	carga()
			


		


elif mode[0]=='remove_download':
	video = args['foldername'][0]
	
	yesno =xbmcgui.Dialog().yesno(addonname, text_file_delete_yesno)
	if yesno==1:
		if os.path.exists(download_path+video): os.remove(download_path+video)
		if os.path.exists(download_path+video+".txt"):os.remove(download_path+video+".txt")
		xbmcgui.Dialog().ok(addonname, text_file_deleted)
		xbmc.executebuiltin('Container.Refresh')



elif mode[0]=='cancel_download':
	xbmcgui.Dialog().ok(addonname, text_file_canceled)
	xbmc.executebuiltin('Container.Refresh')



elif mode[0]=='refresh_download':
	xbmc.executebuiltin('Container.Refresh')






elif mode[0]=='download':
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
	addonPath = xbmcaddon.Addon().getAddonInfo("path")
	#test if is dowloaded or download yet
	directory=download_path
	yesno =xbmcgui.Dialog().yesno(addonname, text_file_downloaded_yesno)
	if yesno==1:
		id = args['foldername'][0]
		#get the "enceoded video"
		video=get_url(id)
		video=video['url']
		filename=os.path.basename(video)
		keyboard = xbmc.Keyboard(filename, text_name_download, False)
		keyboard.doModal()
		if keyboard.isConfirmed() and keyboard.getText() != "":
			new_filename=keyboard.getText()
			if os.path.isfile(directory+new_filename) :
				xbmcgui.Dialog().ok(addonname, text_file_exist)
				xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
			else:
				xbmcgui.Dialog().ok(addonname, text_file_downloaded)
				if not os.path.exists(directory):os.makedirs(directory)
				directory=download_path
				file_txt=directory+"/"+new_filename+".txt"
				f=open(file_txt, "w+")
				f.write("starting...\n")
				f.close()
				xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
				urllib.request.urlretrieve(video, directory+new_filename, reporthook=progress)
		else:
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")	
				



elif mode[0]=='my_favorites':
	foldername = args['foldername'][0]
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
	video = args['foldername'][0]
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	#test if login is correct (if it's not remove the value in settings)ç
	login_url="http://filesmonster.com/api/public/login"
	d = dict(username=username, password=password)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8')
	request = urllib.request.Request(login_url, data)
	
	try:
		response=urllib.request.urlopen(request, timeout = 100)
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
	except urllib.error.URLError as e:
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, "timeout error: try agin")
	
	#cookies=response.info()['Set-Cookie']
	cookies = '; '.join(x.split(';', 1)[0] for x in response.headers.get("Set-Cookie"))
	cookies=cookies.replace("yab_logined=0;", "")
	cookies=cookies.replace("yab_uid=0;", "")
	data=response.read()
	data=json.loads(data)
	status=data['status']
	if status=='fail': xbmcgui.Dialog().ok(addonname, text_no_premium)
	if status=='success':
		#list favorites
		favorite_url="http://filesmonster.com/api/public/listFavorites"
		
		cookieProcessor = urllib.request.HTTPCookieProcessor()
		opener = urllib.request.build_opener(cookieProcessor) 
		response = opener.open(request,timeout=100)
		
		d = dict(url=video)
		f = urllib.parse.urlencode(d)
		post = f.encode('utf-8')	
		data = opener.open(favorite_url, post)
		data=data.read()
		data=json.loads(data)
		cuantos=len(data['favorites'])
		count=0
		while count<cuantos:
			title=data['favorites'][count]['name']
			url_base=data['favorites'][count]['url']
			url_main=data['favorites'][count]['url']
			base=url_base.split("=")
			is_folder="no"
			if "fid" in url_base: is_folder="yes"
			id_base=base[1]
			count=count+1
			
			
			#get info of the video
			thumbnail=''
			genre_s="file"
			year=''
			duration='0:0:0'
			video_format="480x368, DivX 5, 814kbps"
			audio_format=""
			studio=""
			castfull=''
			director=''
			fanart=''
			plot=''
			language='English'
			category='favorites'
			url=''

			thumbnail=thumbnail.strip()
			
			what_icon=""
			if is_folder=="yes": what_icon="[COLOR red][+][/COLOR] "
			li = xbmcgui.ListItem(what_icon+title)
			li.setArt({'icon':favorites_icon})
			li.setArt({'fanart':fanart_main})
			url2 = build_url({'mode':'settings', 'foldername': 'settings'})
			settings=(status_login, 'RunPlugin('+url2+')')  
			if (active=='active'):

				url2 = build_url({'mode':'remove_favorites', 'foldername': url_main})
				video_value=(text_remove_from_my_favorites, 'RunPlugin('+url2+')' )
				url2 = build_url({'mode':'download', 'foldername': id_base})
				video_value2=(text_download_video, 'RunPlugin('+url2+')')
			li.addContextMenuItems([ video_value,  settings ] ,replaceItems=True)
			if is_folder=="yes": url = build_url({'mode': 'afolder', 'foldername': id_base})
			if is_folder=="no": url = build_url({'mode': 'detail_one', 'foldername': id_base})
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True) 





elif mode[0]=='favorites':
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
	video = args['foldername'][0]
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	#test if login is correct (if it's not remove the value in settings)ç
	login_url="http://filesmonster.com/api/public/login"
	d = dict(username=username, password=password)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8')
	request = urllib.request.Request(login_url, data)

	
	try:
		response=urllib.request.urlopen(request, timeout = 100)
	except urllib.error.URLError as e:
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, "timeout error: try agin")
	#cookies=response.info()['Set-Cookie']
	cookies = '; '.join(x.split(';', 1)[0] for x in response.headers.get("Set-Cookie"))
	cookies=cookies.replace("yab_logined=0;", "")
	cookies=cookies.replace("yab_uid=0;", "")
	data=response.read()
	data=json.loads(data)
	status=data['status']
	
	#test if is favorite
	favorite_url="http://filesmonster.com/api/public/isFavorite"
	
	cookieProcessor = urllib.request.HTTPCookieProcessor()
	opener = urllib.request.build_opener(cookieProcessor) 
	response = opener.open(request,timeout=100)
	
	d = dict(url=video)
	f = urllib.parse.urlencode(d)
	post = f.encode('utf-8')

	data = opener.open(favorite_url, post)
	data=data.read()
	data=json.loads(data)
	is_favorite=data['is_favorite']
	is_favorite=str(is_favorite)	
	if is_favorite=='True': 
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, text_yet_favorites)
		
	if status=='success' and is_favorite=='False' :
		#add to favorite
		favorite_url="http://filesmonster.com/api/public/addFavorite"
		cookieProcessor = urllib.request.HTTPCookieProcessor()
		opener = urllib.request.build_opener(cookieProcessor) 
		response = opener.open(request,timeout=100)
	
		d = dict(url=video)
		f = urllib.parse.urlencode(d)
		post = f.encode('utf-8')

		data = opener.open(favorite_url, post)
		data=data.read()
		data=json.loads(data)
		url=''
		status=data['status']
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		if status=='success': 
			xbmcgui.Dialog().ok(addonname, text_added_favorites)
		if status!='success':
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
			fail_reason=data['fail_reason']
			xbmcgui.Dialog().ok(addonname, fail_reason+" "+video)
	



elif mode[0]=='remove_favorites':
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
	video = args['foldername'][0]
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	#test if login is correct (if it's not remove the value in settings)ç
	login_url="http://filesmonster.com/api/public/login"
	d = dict(username=username, password=password)
	f = urllib.parse.urlencode(d)
	data = f.encode('utf-8')
	request = urllib.request.Request(login_url, data)
	
	try:
		response=urllib.request.urlopen(request, timeout = 10)
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

	except urllib.error.URLError as e:
		xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
		xbmcgui.Dialog().ok(addonname, "timeout error: try agin")
		
	#cookies=response.info()['Set-Cookie']
	cookies = '; '.join(x.split(';', 1)[0] for x in response.headers.get("Set-Cookie"))
	cookies=cookies.replace("yab_logined=0;", "")
	cookies=cookies.replace("yab_uid=0;", "")
	data=response.read()
	data=json.loads(data)
	status=data['status']
	
	if status=='success' :
		#add to favorite
		favorite_url="http://filesmonster.com/api/public/removeFavorite"
		cookieProcessor = urllib.request.HTTPCookieProcessor()
		opener = urllib.request.build_opener(cookieProcessor) 
		response = opener.open(request,timeout=100)
		
		d = dict(url=video)
		f = urllib.parse.urlencode(d)
		post = f.encode('utf-8')

		data = opener.open(favorite_url, post)
		data=data.read()
		data=json.loads(data)
		url=''
		status=data['status']
		if status=='success': 
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
			xbmc.executebuiltin('Container.Refresh')
		if status!='success':
			xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
			fail_reason=data['fail_reason']
			xbmcgui.Dialog().ok(addonname, fail_reason+" "+video)
	




elif mode[0]=='play_video':
	xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
	id = args['foldername'][0]
	title = ""
	thumb = ""
	plot = ""
	data=get_url(id)
	url=data['url']
	title=data['title']
	thumb=data['thumbnail']
	argument=data['plot']
	xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

	#xbmc.executebuiltin('xbmc.PlayMedia("'+url+'")')
	li = xbmcgui.ListItem(label=title,  path=url)
	li.setArt({'thumbnail':thumb})
	li.setArt({'icon':thumb})
	xbmc.Player().play(item=url, listitem=li)
	
	
	
	           
	           
elif mode[0]=='no_premium':
	xbmcgui.Dialog().ok(addonname, text_no_premium)



elif mode[0]=='afolder':
	id = args['foldername'][0]
	#scraped info from folder scraped from website
	link="http://filesmonster.com/folders.php?fid="+id
	request = urllib.request.Request(link)
	result = urllib.request.urlopen(request)
	data2=result.read().decode('utf-8')

	patronvideos = 'download.php(.*?)">(.*?)</a>'
	matches = re.compile(patronvideos,re.DOTALL).findall(data2)
	for link , title in matches:
		url_main=link
		id=link.split("=")
		id=id[1]
		id_base=id
		thumbnail=favorites_icon
		title=title.strip()
		thumbnail=thumbnail.strip()
	
		li = xbmcgui.ListItem(title)
		li.setArt({'icon':favorites_icon})
		li.setArt({'fanart':fanart_main, 'thumbanil':thumbnail, 'poster':thumbnail, 'banner':fanart_main})
		url2 = build_url({'mode':'settings', 'foldername': 'settings'})
		settings=(status_login, 'RunPlugin('+url2+')')  
		url2 = build_url({'mode':'remove_favorites', 'foldername': url_main})
		video_value=(text_remove_from_my_favorites, 'RunPlugin('+url2+')' )
		url2 = build_url({'mode':'download', 'foldername': id_base})
		video_value2=(text_download_video, 'RunPlugin('+url2+')')
		li.addContextMenuItems([   settings ] ,replaceItems=True)
		url = build_url({'mode': 'detail_one', 'foldername': id_base})
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True) 
		
	
	#test if there's a new page
	patronvideos = 'href=\'/folders.php(.*?)\'>(.*?)</a>'
	matches = re.compile(patronvideos,re.DOTALL).findall(data2)
	for link, count  in matches:
		url_main=link
		id=link.split("fid=")
		id=id[1]
		id_base=id
		title=''
		thumbnail=next_icon
		thumbnail=thumbnail.strip()
		count=count.strip()
		li = xbmcgui.ListItem(text_page+" "+count)
		li.setArt({'icon':next_icon})
		li.setArt({'fanart':fanart_main, 'thumbanil':thumbnail,  'poster':thumbnail, 'banner':fanart_main})
		url2 = build_url({'mode':'settings', 'foldername': 'settings'})
		settings=(status_login, 'RunPlugin('+url2+')')  
		url2 = build_url({'mode':'remove_favorites', 'foldername': url_main})
		video_value=(text_remove_from_my_favorites, 'RunPlugin('+url2+')' )
		url2 = build_url({'mode':'download', 'foldername': id_base})
		video_value2=(text_download_video, 'RunPlugin('+url2+')')
		li.addContextMenuItems([ video_value,  settings ] ,replaceItems=True)
		url = build_url({'mode': 'afolder', 'foldername': id_base})
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True) 
	
	
	

elif mode[0]=='detail_one':

	id_base=''
	is_folder="no"
	active = my_addon.getSetting('active')
	url=''
	thumbnail=''
	category=''
	active="active"	
	year='n/a'
	
	
	
	
	id = args['foldername'][0]
	data=get_url(id)
	title=data['title']
	url=data['url']
	thumbnail=data['thumbnail']
	description=data['plot']
	category=data['category']
	
	if thumbnail is None: thumbnail=favorites_icon
	if category is None: category=""
	if url is None: url=""
	if description is None: description=""
	
	url_main="http://filesmonster.com/download.php?id="+id
	id_base=id




	data=get_info(description, url_main)
	duration_s=data['duration_s']
	language_s=data['language_s']
	audio_chanells=data['audio_chanells']
	codec_format_1=data['codec_format_1']	
	width=data['width']	
	height=data['height']	
	aspect=data['aspect']	
	plot=data['plot']	
	title=data['title']	
	fanart=data['fanart']	
	genre=data['genre_s']
	video=data['video']		
	year=data['year']	
	studio=data['studio']	
	director=data['director']	
	cast=data['cast']
	
	fanart=fanart.replace("imager/w_400/h_400", "pic_b")
	fanart=fanart.replace("imager/w_200/h_200", "pic_b")
	fanart=fanart.replace("imager/w_400/h_500", "pic_b")
	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
	thumbnail=thumbnail.replace("imager/w_400/h_400", "pic_b")
	thumbnail=thumbnail.replace("imager/w_400/h_500", "pic_b")
	thumbnail=thumbnail.replace("imager/w_200/h_200", "pic_b")	
	thumbnail=thumbnail.strip()
	plot=plot.strip()
	genre=genre+" ("+category+")"

	thumbnail=thumbnail.strip()
	poster=thumbnail 
	banner=fanart

	li = xbmcgui.ListItem(title)
	li.setArt({'icon':favorites_icon})
	info = {'genre': genre,'year': year,'title': title, 'originaltitle':title, 'studio':studio, 'director':director,  'cast':cast, 'plot':plot, 'mpaa': 'NC-17',  'duration':duration_s }
	li.setInfo('video', info)
	li.setArt({'fanart':fanart, 'thumb':thumbnail , 'poster':poster , 'banner':banner})
	li.addStreamInfo('audio', { 'language': language_s,  'channels': audio_chanells})
	li.addStreamInfo('video', {'codec': codec_format_1, 'width': width ,'height': height , 'aspect':aspect, })
	url2 = build_url({'mode':'settings', 'foldername': 'settings'})
	settings=(status_login, 'RunPlugin('+url2+')')  
	url2 = build_url({'mode':'remove_favorites', 'foldername': url_main})
	video_value=(text_remove_from_my_favorites, 'RunPlugin('+url2+')' )
	url2 = build_url({'mode':'download', 'foldername': id_base})
	video_value2=(text_download_video, 'RunPlugin('+url2+')')
	url = build_url({'mode': 'play_video', 'foldername': id_base})
	li.addContextMenuItems([ video_value, video_value2,  settings ] ,replaceItems=True)
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False) 
	
	
	






xbmcplugin.endOfDirectory(addon_handle)

	
