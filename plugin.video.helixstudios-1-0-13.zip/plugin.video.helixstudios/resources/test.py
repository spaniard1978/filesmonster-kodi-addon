			

			
			
			#get kodi version
			xbmc_version = xbmc.getInfoLabel( "System.BuildVersion" )
			version=xbmc_version.split(" ")
			version=version[0]
			version=version.split(".")
			version=version[0]
			#oficial database versions: (only jarvis or upper) http://kodi.wiki/view/database_versions
			if version=='16': database="MyVideos99.db"
			#if is not this version not load because get error
			if base!='':
				try:
					from sqlite3 import dbapi2 as sqlite
				except:
					from pysqlite2 import dbapi2 as sqlite
					DB = os.path.join(xbmc.translatePath("special://database"), base)
					db = sqlite.connect(DB)
					db.execute('INSERT into actor (name, art_urls) values ("Dylan Hall", "https://cdn.helixstudios.com/img/320w/media/headshots/dylan-hall.1418920205.jpg" )' )
					db.commit()
					db.close()

			